import 'package:dio/dio.dart';

HttpClientAdapter httpAdapter() => throw UnsupportedError('');
