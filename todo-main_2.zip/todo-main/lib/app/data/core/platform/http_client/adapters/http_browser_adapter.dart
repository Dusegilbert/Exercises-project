import 'package:dio/adapter_browser.dart';

BrowserHttpClientAdapter httpAdapter() => BrowserHttpClientAdapter();
