import 'package:flutter/material.dart';

const appBarTheme = AppBarTheme(
  elevation: 0,
  backgroundColor: Colors.transparent,
  centerTitle: true,
);
