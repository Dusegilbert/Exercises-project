part of 'update_ussd_bloc.dart';

@freezed
class UpdateUssdEvent with _$UpdateUssdEvent {
  const factory UpdateUssdEvent.loadData() = _LoadData;
}
