# Historial de Cambios

## 2.0.0

Cambios en la interfaz de usuario.
Agregada pantalla de acciones recientes.