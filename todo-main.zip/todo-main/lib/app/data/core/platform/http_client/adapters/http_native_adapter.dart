import 'package:dio/adapter.dart';

DefaultHttpClientAdapter httpAdapter() => DefaultHttpClientAdapter();
