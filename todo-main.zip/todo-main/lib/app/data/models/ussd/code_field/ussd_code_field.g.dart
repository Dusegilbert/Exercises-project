// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ussd_code_field.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UssdCodeField _$UssdCodeFieldFromJson(Map<String, dynamic> json) {
  return UssdCodeField(
    name: json['name'] as String,
    type: json['type'] as String,
  );
}

Map<String, dynamic> _$UssdCodeFieldToJson(UssdCodeField instance) =>
    <String, dynamic>{
      'name': instance.name,
      'type': instance.type,
    };
