
<li>
    <a wire:click='add_to_cart()'><i
        class="tf-ion-android-cart"></i></a>
    </li>
