<li>
    <a wire:click='save_like()'><i
            class="tf-ion-ios-heart"></i> </a>
</li>
