@extends('admin.layouts.app')
@section('admin.content')

@livewire('admin.category')

@endsection
