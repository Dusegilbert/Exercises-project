@extends('layouts.app')
@section('content')

@livewire('cart')


@endsection
