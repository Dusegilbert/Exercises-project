
## Zshop 

Zshop is e-commerse based web application build with **laravel** by [Tauseed Zaman](https://github.com/tauseedzaman).
### How to Install Zshop 

- **Clone/Download the repo**
- **composer install**
- **copy .env.example .env**
- **php artisan key:generate**
- **php artisan migrate**
- **php artisan db:seed**
- **php artisan serve**
- **[http://127.0.0.1:8000/](http://127.0.0.1:8000/)**


## License

The Zshop is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

